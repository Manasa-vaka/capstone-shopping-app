import React from 'react'

export default function Footer() {
  return (


    

   

    <div  >
        <div class="container">
        <div bgcolor ="pink">
       <footer class="row row-cols-5 py-5 my-5 border-top">
       
      <div class="col">
      <p><h3>Shopping <br></br><h4>App</h4></h3></p>
      <br/>
      
    </div>

    <div class="col">

    </div>

    <div class="col">
      <h5>Our Services</h5>
      <ul class="nav flex-column">
        <li class="nav-item mb-2">Women Clothing</li>
        <li class="nav-item mb-2">Men Clothing</li>
        <li class="nav-item mb-2">Kid's Clothing</li>

      </ul>
    </div>

    <div class="col">
      <h5>Our Websites</h5>
      <ul class="nav flex-column">
        <li class="nav-item mb-2"><a href="https://www.ajio.com/" class="nav-link p-0 text-muted">Ajio</a></li>
        <li class="nav-item mb-2"><a href="https://www.myntra.com/?utm_source=perf_bing_traffic&utm_medium=perf_bing_traffic&utm_campaign=Bing_Brand_BMM_Desktop&utm_source=bing" class="nav-link p-0 text-muted">Myntra</a></li>
        <li class="nav-item mb-2"><a href="https://www.amazon.in/" class="nav-link p-0 text-muted">Amazon</a></li>
        <li class="nav-item mb-2"><a href="https://meesho.com/" class="nav-link p-0 text-muted">meesho</a></li>
        <li class="nav-item mb-2"><a href="https://www.flipkart.com/" class="nav-link p-0 text-muted">Flipkart</a></li>
      </ul>
    </div>

    <div class="col">
      <h5>Address</h5>
      <ul class="nav flex-column">
        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">address:G-13,2nd Floor,sec-3,nehru road</a></li>
        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Noida,up,201301,India</a></li>
        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">contact no:9876578643</a></li>
      
        <div class="col-xs-10">
          <a href="vmreddy@gmail.com">vmreddy@gmail.com</a>
        </div>
        
         
         

      </ul>
    </div>


      <div class="col-md-4">
                        <div class="iframeMap">
                        <iframe id="gmap_canvas" height="200" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=520&amp;height=400&amp;hl=en&amp;q=noida%20Road,%20haridwar%20SPSR%20noida+(PBR%20VITS)&amp;t=&amp;z=7&amp;ie=UTF8&amp;iwloc=B&amp;output=embed">

                            </iframe>

                        </div>
                    </div>
      
   
  </footer>
  <h4 align ="center"><p className='text-muted p-0'>Designed And Developed By: G2B2</p></h4>
      
 
  </div>

    </div>
    </div>
  



  )
}