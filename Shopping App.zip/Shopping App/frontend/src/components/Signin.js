import React from 'react'




export default function Login() {
  return (


    <>
    <div class = "mb-7">
     <form className='container form'>
     <div class="mb-3">
    <label for="userName" class="form-label">Name</label>
    <input type="name" class="form-control" id="userName"/>
  </div>
  
  <div class="mb-3">
    <label for="userEmail" class="form-label">Email address</label>
    <input type="email" class="form-control" id="userEmail" aria-describedby="emailHelp"/>
  </div>
  <div class="mb-3">
    <label for="userPassword" class="form-label">Phone Number</label>
    <input type="password" class="form-control" id="userPassword"/>
  </div>  
 
  <button type="submit" class="btn btn-primary">Submit</button>
</form>   

</div>

        

    
</>
  )
}

   
  